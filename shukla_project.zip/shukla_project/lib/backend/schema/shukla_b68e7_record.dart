import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ShuklaB68e7Record extends FirestoreRecord {
  ShuklaB68e7Record._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "password" field.
  String? _password;
  String get password => _password ?? '';
  bool hasPassword() => _password != null;

  // "firstname" field.
  String? _firstname;
  String get firstname => _firstname ?? '';
  bool hasFirstname() => _firstname != null;

  // "lastname" field.
  String? _lastname;
  String get lastname => _lastname ?? '';
  bool hasLastname() => _lastname != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _password = snapshotData['password'] as String?;
    _firstname = snapshotData['firstname'] as String?;
    _lastname = snapshotData['lastname'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('shukla-b68e7');

  static Stream<ShuklaB68e7Record> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ShuklaB68e7Record.fromSnapshot(s));

  static Future<ShuklaB68e7Record> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ShuklaB68e7Record.fromSnapshot(s));

  static ShuklaB68e7Record fromSnapshot(DocumentSnapshot snapshot) =>
      ShuklaB68e7Record._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ShuklaB68e7Record getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ShuklaB68e7Record._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ShuklaB68e7Record(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ShuklaB68e7Record &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createShuklaB68e7RecordData({
  String? email,
  String? displayName,
  String? photoUrl,
  String? uid,
  String? phoneNumber,
  String? password,
  String? firstname,
  String? lastname,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'phone_number': phoneNumber,
      'password': password,
      'firstname': firstname,
      'lastname': lastname,
    }.withoutNulls,
  );

  return firestoreData;
}

class ShuklaB68e7RecordDocumentEquality implements Equality<ShuklaB68e7Record> {
  const ShuklaB68e7RecordDocumentEquality();

  @override
  bool equals(ShuklaB68e7Record? e1, ShuklaB68e7Record? e2) {
    return e1?.email == e2?.email &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.password == e2?.password &&
        e1?.firstname == e2?.firstname &&
        e1?.lastname == e2?.lastname;
  }

  @override
  int hash(ShuklaB68e7Record? e) => const ListEquality().hash([
        e?.email,
        e?.displayName,
        e?.photoUrl,
        e?.uid,
        e?.phoneNumber,
        e?.password,
        e?.firstname,
        e?.lastname
      ]);

  @override
  bool isValidKey(Object? o) => o is ShuklaB68e7Record;
}
