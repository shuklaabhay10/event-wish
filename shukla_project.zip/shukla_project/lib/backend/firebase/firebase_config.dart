import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDM2jmV9hYjdfVB9QH6E3VwzGDYbS6pCVA",
            authDomain: "shukla-b68e7.firebaseapp.com",
            projectId: "shukla-b68e7",
            storageBucket: "shukla-b68e7.appspot.com",
            messagingSenderId: "490246374907",
            appId: "1:490246374907:web:27d28b132f5f2f6f30b75e"));
  } else {
    await Firebase.initializeApp();
  }
}
