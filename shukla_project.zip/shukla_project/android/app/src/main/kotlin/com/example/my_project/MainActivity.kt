package com.mycompany.shuklaproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
